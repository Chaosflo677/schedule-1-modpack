Mod Manager & Phone App - LICENSE

Copyright (c) 2025. All rights reserved.

License Grant:

The copyright holder grants you ("Licensee") a limited, non-exclusive, non-transferable, revocable license to install and use one copy of this software modification ("Mod") solely for your personal, non-commercial use with the specified compatible game ("Schedule I").

Restrictions:

Unless otherwise explicitly agreed upon in writing by the copyright holder (2025), you are expressly prohibited from doing any of the following:

1.  Decompilation and Reverse Engineering: You may not decompile, disassemble, reverse engineer, or otherwise attempt to derive the source code or underlying structure, ideas, or algorithms of the Mod, except to the extent that such activity is expressly permitted by applicable law notwithstanding this limitation.
2.  Modification: You may not modify, adapt, translate, or create derivative works based on the Mod or any part thereof.
3.  Distribution and Redistribution: You may not distribute, redistribute, sublicense, rent, lease, lend, sell, assign, or otherwise transfer the Mod, copies of the Mod, or any rights granted by this license to any third party, whether for commercial or non-commercial purposes. This includes, but is not limited to, uploading the Mod to websites, file-sharing services, or modding platforms other than the original official distribution point designated by the copyright holder.
4.  Commercial Use: You may not use the Mod for any commercial purpose, including but not limited to selling the Mod, selling access to the Mod, or using the Mod as part of a commercial service.
5.  Removing Notices: You may not remove or alter any copyright, trademark, or other proprietary notices contained within or on the Mod.

Ownership:

This license does not grant you any ownership rights to the Mod. The copyright holder retains all right, title, and interest in and to the Mod, including all intellectual property rights therein.

Disclaimer of Warranty:

THE MOD IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE MOD OR THE USE OR OTHER DEALINGS IN THE MOD.

Governing Law:

This license shall be governed by and construed in accordance with the laws of the jurisdiction deemed applicable by the copyright holder, without regard to its conflict of law provisions.

Termination:

This license will terminate automatically if you breach any of its terms and conditions. Upon termination, you must immediately cease all use of the Mod and destroy all copies of the Mod in your possession or control.

By installing or using the Mod, you acknowledge that you have read this license, understand it, and agree to be bound by its terms and conditions. If you do not agree to these terms, do not install or use the Mod.